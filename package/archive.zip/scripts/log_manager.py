#!/use/bin/env python
# coding = utf-8

from resource_management import *


def conf():
    import params
    import status_params
    # WARNING: You must specify that the group is elasticsearch, if not will start fail.
    # dircreated = [params.elastic_dir,
    #               params.pid_dir,
    #               params.path_data]
    #
    # Directory(dircreated,
    #           owner=params.elastic_user,
    #           group=params.elastic_group,
    #           create_parents=True
    #           )

    File(params.logstash_yml_conf,
         owner=params.logstash_user,
         group=params.logstash_group,
         content=InlineTemplate(params.logstash_yml)
         )

    File(params.startup_conf,
         owner=params.logstash_user,
         group=params.logstash_group,
         content=InlineTemplate(params.startup_options)
         )
    File(params.logtest_conf,
         owner=params.logstash_user,
         group=params.logstash_group,
         content=InlineTemplate(params.log_es)
         )

    File(status_params.logstash_pid,
         owner=params.logstash_user,
         group=params.logstash_group
         )

    # File(format("{pid_dir}/es.pid"),
    #      owner=params.elastic_user,
    #      group=params.elastic_group
    #      )
