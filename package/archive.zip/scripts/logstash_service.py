# coding=utf-8
from resource_management import *
from resource_management.core.resources.system import File


def logstash_service(name=None,pid=None):
    import status_params
    if name == "config":
        # create pid file
        # Directory(status_params.logstash_pid_dir,
        #           create_parents=True
        #           )

        File(status_params.logstash_pid,
             content=pid + "\n"
             )
